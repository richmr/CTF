#!/bin/bash

# Demux media file (only H264 video streams accepted).
ffmpeg -i "$1" -vcodec copy -an -bsf:v h264_mp4toannexb -y "$1.h264"

# Encrypt video.
./encrypt_video "$1.h264" "$2" > "$1.h264.enc"

# Encrypt audio.
ffmpeg -i "$1" -vn -ac 1 -ar 44100 -f s16le -acodec pcm_s16le - | python encrypt_audio.py -k "$2" | ffmpeg -f s16le -ac 1 -ar 44100 -i - -y "$1.wav"

# Mux media.
ffmpeg -i "$1.h264.enc" -i "$1.wav" -vcodec copy -acodec copy -y "$1.enc.avi"

# Remove temporary files.
rm "$1.h264" "$1.h264.enc" "$1.wav"

# Play media.
# ffplay "$1.enc.avi"
